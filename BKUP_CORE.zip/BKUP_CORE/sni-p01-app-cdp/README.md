# sni-p01-app-cdp

**Cloud Data Platform codecommit/codebuild pipeline**

## run locally

a script named `./terraform_pipeline_local.py` is provided at the root of this repo.
Run this script to _simulate_ the same behaviour of the cobuild pipeline, by fetching _ssm parameters_ specified in the `buildspec.yml` file and pass them to the terraform shell environment.
Pass the terraform action to the script.

```
./terraform_pipeline_local.py plan
./terraform_pipeline_local.py plan -target resource
```

**NB**: The terraform configuration is assuming a copy of the `sni-01-tf-modules` is reachable in `../modules`, like the container that runs the pipeline in codebuild.
The script doesn't manage that, so be sure it's present before running terraform.
