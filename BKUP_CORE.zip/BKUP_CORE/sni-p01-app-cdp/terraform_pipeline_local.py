#!/usr/bin/env python

'''
Author: Contino

tiny wrapper to run pipelines locally, replicating
SNI Landing Zone codebuild pipelines' behaviour.
It fetch variables from AWS parameters store
and serves them as TF_VAR environment variables to terraform.
A set of arguments can be passed over to the script,
as the terraform command to chain run, ie:
- 'plan'
- 'apply -target=resource'

Any local state management terraform command
can be run without the wrapper, like:
- terraform init
- terraform state list
- terraform output

TODO: use the container instead.

'''

import yaml,sys
import os, subprocess
import boto3

tfenv = dict()

# this is to workaround https://github.com/terraform-providers/terraform-provider-aws/issues/7750
# AWS SDK doesnt look for a region in the aws credentials file when passing AWS_PROFILE
tfenv['AWS_DEFAULT_REGION']='us-east-2'

bashenv = dict(os.environ)   # Make a copy of the current environment

with open('buildspec.yml', 'r') as yamlfile:
    try:
        yaml=yaml.safe_load(yamlfile)
    except yaml.YAMLError as exc:
        print(exc)
        sys.exit(1)    

ssm = boto3.client('ssm')
for p in yaml['env']['parameter-store']:
    parameter = ssm.get_parameter(Name=yaml['env']['parameter-store'][p], WithDecryption=True)
    tfenv[p]=parameter['Parameter']['Value']
bashenv.update(tfenv)

tf_args=' '.join(sys.argv[1:])
print("Running 'terraform %s' with env variables:" % tf_args)
for x in tfenv.keys():
    print("- %s" % x)

args='terraform ' + tf_args
tf=subprocess.Popen(args, env=bashenv, shell=True)
tf.wait()
#