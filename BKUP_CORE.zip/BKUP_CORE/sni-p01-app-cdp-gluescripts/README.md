# sni-p01-app-cdp-gluescripts

_This repo has no pipeline_

It is used instead by the app-cdp pipeline to push scripts for glue jobs.
