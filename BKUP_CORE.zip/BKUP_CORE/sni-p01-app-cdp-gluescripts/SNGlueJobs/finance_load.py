import sys
import uuid
from datetime import datetime

import boto3
from pyspark.context import SparkContext
from pyspark.sql.types import *

from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.utils import getResolvedOptions

# The csv file should have the columns headers in this list.
MAPPINGS = [("Version", "string", "version", "string"),
            ("Year", "string", "year", "long"),
            ("Period", "string", "period", "long"),
            ("HFM Legal Entity", "string", "hfm_legal_entity", "string"),
            ("Rep Currency", "string", "rep_currency", "string"),
            ("Customer", "string", "customer", "string"),
            ("Product Code", "string", "product_code", "string"),
            ("Product Name", "string", "product_name", "string"),
            ("Data", "string", "data", "string"),
            ("Measure", "string", "measure", "string"),
            ("Amount", "string", "amount", "float")]


def create_csv_dataframe(gc, s3_file_path):
    """
    Loads the CSV file into a dynamic dataframe
    :param gc: The glueContext to use to create the dynamicframe.
    :param s3_file_path: The a csv list of s3 keys to load.
    :return: A dynamic frame containing rows from the file
    """
    csv_dataframe = gc.create_dynamic_frame_from_options("s3", {"paths": s3_file_path},
                                                         format="csv",
                                                         format_options={"withHeader": True})
    return csv_dataframe


def validate_file(csv_dataframe):
    """
    Validates that the number of columns and names match what is expected. Raises an error if not.
    :param csv_dataframe: The dataframe to check.
    :return: Nothing
    """
    csv_fields = [f.name for f in csv_dataframe.schema().fields]
    mapping_fields = [m[0] for m in MAPPINGS]
    if csv_fields != mapping_fields:
        raise ValueError("Source fields differ to the defined schema! \n"
                         "{0}\n instead of \n{1}".format(csv_fields, mapping_fields))


def rename_columns(csv_dataframe):
    """
    Rename the columns in the CSV file to match the Redshift table columns, otherwise they will be added as new columns.
    :param csv_dataframe: The dataframe with the columns to rename.
    :return: A dynamic dataframe.
    """
    renamed_dataframe = csv_dataframe.apply_mapping(mappings=MAPPINGS)

    return renamed_dataframe


def write_dataframe_to_s3(gc, dataframe, s3_path):
    """
    Writes the frame to S3 partitioned on the version in GZIP format.
    :param gc: The GlueContext to use to write the dataframe to S3.
    :param dataframe: The dataframe to save to S3.
    :param s3_path: The path to save the output files to.
    :return: Nothing
    """
    gc.write_dynamic_frame.from_options(frame=dataframe,
                                        connection_type="s3",
                                        connection_options={"path": s3_path,
                                                            "compression": "gzip",
                                                            "partitionKeys": ["version"]},
                                        format="csv")


def create_audit_dataframe(gc, execution_uuid, subprocess, ):
    """
    Writes a row to the dim_audit table to track job executions.
    :param gc: The GlueContext to use to create a dynamic dataframe.
    :param execution_uuid: A UUID to identify each excution of the finance load.
    :param subprocess: The subprocess to log.
    :return: A Spark dataframe representing a row in the audit table.
    """
    spark = gc.spark_session

    audit_row = [{"execution_uuid": execution_uuid,
                  "process_name": "Finance Load",
                  "subprocess_name": subprocess,
                  "start_date": datetime.now(),
                  "rows_inserted": 0,
                  "status": "Started"
                  }]

    schema = StructType([
        StructField('execution_uuid', StringType(), False),
        StructField('process_name', StringType(), False),
        StructField('subprocess_name', StringType(), False),
        StructField('start_date', TimestampType(), False),
        StructField('rows_inserted', IntegerType(), False),
        StructField('status', StringType(), False)
    ])

    audit_dataframe = spark.createDataFrame(data=audit_row, schema=schema)
    audit_dyn_df = DynamicFrame.fromDF(audit_dataframe, gc, "audit_frame")

    return audit_dyn_df


def write_data_to_redshift(gc, execution_uuid, subprocess, temp_dir, preaction_query,
                           postaction_query):
    """
    Writes an entry to the dim_audit table and runs a Redshift COPY command to load the fact tables.
    :param gc: The GlueContext to use to write to Redshift.
    :param execution_uuid: A UUID to identify each excution of the finance load.
    :param subprocess: The subprocess name to write to the dim_audit table.
    :param temp_dir: The S3 location to store temporary files.
    :param preaction_query: The query to execute before running the COPY operation.
    :param postaction_query: The query to execute after running the COPY operation.
    :return:
    """
    audit_df = create_audit_dataframe(glueContext, execution_uuid, subprocess)

    gc.write_dynamic_frame.from_jdbc_conf(frame=audit_df,
                                          catalog_connection="redshift-sni-dev",
                                          connection_options={
                                              "preactions": preaction_query,
                                              "dbtable": "finance_dwh.dim_audit",
                                              "database": "sni",
                                              "postactions": postaction_query
                                          },
                                          redshift_tmp_dir=temp_dir
                                          )


if __name__ == "__main__":
    glueContext = GlueContext(SparkContext.getOrCreate())
    logger = glueContext.get_logger()

    args = getResolvedOptions(sys.argv,
                              ["JOB_NAME",
                               "s3_input_file",
                               "s3_output_path",
                               "redshift_tmp_dir"]
                              )

    s3_file = args["s3_input_file"].split(",")
    s3_output_path = args["s3_output_path"]
    redshift_tmp_dir = args["redshift_tmp_dir"]

    execution_id = str(uuid.uuid4())
    now = datetime.now()
    effective_date = now.strftime("%Y%m%d")

    logger.info("Processing {}".format(s3_file))
    csv_df = create_csv_dataframe(glueContext, s3_file)
    csv_row_count = csv_df.count()
    logger.info("{} rows in the source file(s)".format(csv_row_count))

    cloudwatch = boto3.client("cloudwatch", region_name="us-east-2")
    # Put custom metrics
    cloudwatch.put_metric_data(
        MetricData=[
            {
                "MetricName": "NumberOfRows",
                "Dimensions": [
                    {
                        "Name": "JobName",
                        "Value": args["JOB_NAME"]
                    },
                    {
                        "Name": "JobRunId",
                        "Value": args["JOB_RUN_ID"]
                    },
                    {
                        "Name": "S3Key",
                        "Value": args["s3_input_file"]
                    },
                ],
                "Unit": "None",
                "Value": csv_row_count
            },
        ],
        Namespace='Glue/ETL File Metrics'
    )

    logger.info("Validating")
    validate_file(csv_df)
    renamed_df = rename_columns(csv_df)
    logger.info("Writing to S3")
    write_dataframe_to_s3(glueContext, renamed_df, s3_output_path)

    # Load actual prior year data
    subprocess_name = "actual_prior_year_load"
    prior_year_preaction_query = "truncate table finance_dwh.raw_actual_prior_year_revenue_monthly;"
    prior_year_postaction_query = """
    create temp table audit_id as (select id from finance_dwh.dim_audit
    where execution_uuid = '{0}' and subprocess_name = '{1}');
    copy finance_dwh.raw_actual_prior_year_revenue_monthly
    from '{3}version=Actual Prior Year/'
    iam_role 'arn:aws:iam::783569832862:role/sni-dev-role'
    format as csv ignoreheader 1 gzip;
    truncate table finance_dwh.stg_actual_prior_year_revenue_monthly;
    insert into finance_dwh.stg_actual_prior_year_revenue_monthly
    select {2} as dim_calendar_id_effective
    , cal.id as dim_calendar_id_period
    , c.id as dim_customer_id
    , cur.id as dim_currency_id
    , p.id as dim_product_id
    , sum(case when measure = 'Revenue Net of All Adjustments'
        then isnull(amount, 0)
        else 0
        end) as actual_prior_year_revenue_net_of_all_adjustments
    , sum(case when measure = 'Standard See Through Gross Profit Net of All Adjustments'
        then isnull(amount, 0)
        else 0
        end) as actual_prior_year_standard_see_through_gross_profit_net_of_all_adjustments
    from (select distinct * from finance_dwh.raw_actual_prior_year_revenue_monthly) sd
    join finance_dwh.dim_customer c on sd.hfm_legal_entity = c.entity_code and sd.customer = c.code
    join finance_dwh.dim_currency cur on sd.rep_currency = cur.code
    join finance_dwh.dim_product p on sd.product_name = p.name
    join finance_dwh.dim_calendar cal on cal.year = sd.year and cal.month = sd.period
    where not(sd.hfm_legal_entity = 'MO-SNGROUP' and sd.customer = 'MGT-Management Org')
    and c.lowest_hierarchy_level = true
    and cal.end_of_month_flag = true
    group by cal.id, c.id, cur.id, p.id;
    create temp table latest_fact_values as (select dim_calendar_id_period
    , dim_customer_id
    , dim_currency_id
    , dim_product_id
    , sum(actual_prior_year_revenue_net_of_all_adjustments)
    as actual_prior_year_revenue_net_of_all_adjustments
    , sum(actual_prior_year_standard_see_through_gross_profit_net_of_all_adjustments)
    as actual_prior_year_standard_see_through_gross_profit_net_of_all_adjustments
    from finance_dwh.fact_actual_prior_year_revenue_monthly
    group by 1,2,3,4
    order by 1,2,3,4);
    insert into finance_dwh.fact_actual_prior_year_revenue_monthly
    (dim_audit_id
    ,dim_calendar_id_effective
    , dim_calendar_id_period
    , dim_customer_id
    , dim_currency_id
    , dim_product_id
    , actual_prior_year_revenue_net_of_all_adjustments
    , actual_prior_year_standard_see_through_gross_profit_net_of_all_adjustments)
    select (select id from audit_id)
    , stg.dim_calendar_id_effective
    , stg.dim_calendar_id_period
    , stg.dim_customer_id
    , stg.dim_currency_id
    , stg.dim_product_id
    , stg.actual_prior_year_revenue_net_of_all_adjustments
    - isnull(lfv.actual_prior_year_revenue_net_of_all_adjustments, 0)
    , stg.actual_prior_year_standard_see_through_gross_profit_net_of_all_adjustments
    - isnull(lfv.actual_prior_year_standard_see_through_gross_profit_net_of_all_adjustments, 0)
    from finance_dwh.stg_actual_prior_year_revenue_monthly stg
    left join latest_fact_values lfv
    on stg.dim_calendar_id_period = lfv.dim_calendar_id_period
    and stg.dim_customer_id = lfv.dim_customer_id
    and stg.dim_currency_id = lfv.dim_currency_id
    and stg.dim_product_id = lfv.dim_product_id
    where lfv.dim_calendar_id_period is null -- New rows
    or stg.actual_prior_year_revenue_net_of_all_adjustments
        - isnull(lfv.actual_prior_year_revenue_net_of_all_adjustments, 0) <> 0
    or stg.actual_prior_year_standard_see_through_gross_profit_net_of_all_adjustments
        - isnull(lfv.actual_prior_year_standard_see_through_gross_profit_net_of_all_adjustments, 0) <> 0;
    update finance_dwh.dim_audit set end_date = sysdate,
    rows_inserted = (select count(1) from finance_dwh.fact_actual_prior_year_revenue_monthly where dim_audit_id = (select id from audit_id)),
    status = 'Finished'
    where id = (select id from audit_id);""".format(execution_id,
                                                    subprocess_name,
                                                    effective_date,
                                                    s3_output_path
                                                    )
    logger.info("Running {}".format(subprocess_name))
    write_data_to_redshift(glueContext,
                           execution_id,
                           subprocess_name,
                           redshift_tmp_dir,
                           prior_year_preaction_query,
                           prior_year_postaction_query)

    # Load actual revenue
    subprocess_name = "actual_revenue_load"
    actual_revenue_preaction_query = "truncate table finance_dwh.raw_actual_revenue_monthly;"
    actual_revenue_postaction_query = """
    create temp table audit_id as (select id from finance_dwh.dim_audit
    where execution_uuid = '{0}' and subprocess_name = '{1}');
    copy finance_dwh.raw_actual_revenue_monthly
    from '{3}version=Actual/'
    iam_role 'arn:aws:iam::783569832862:role/sni-dev-role'
    format as csv ignoreheader 1 gzip;
    truncate table finance_dwh.stg_actual_revenue_monthly;
    insert into finance_dwh.stg_actual_revenue_monthly
    select {2} as dim_calendar_id_effective
    , cal.id as dim_calendar_id_period
    , c.id as dim_customer_id
    , cur.id as dim_currency_id
    , p.id as dim_product_id
    , sum(case when measure = 'Standard See Through Gross Profit Net of All Adjustments'
        then isnull(amount, 0)
        else 0
        end) as actual_standard_see_through_gross_profit_net_of_all_adjustments
    , sum(case when measure = 'Revenue Net of All Adjustments'
        then isnull(amount, 0)
        else 0
        end) as actual_revenue_net_of_all_adjustments
    , sum(case when measure = 'Re Profit Net of All Adjustments' then amount
        else 0
        end) as actual_re_profit_net_of_all_adjustments
    from (select distinct * from finance_dwh.raw_actual_revenue_monthly) sd
    join finance_dwh.dim_customer c on sd.hfm_legal_entity = c.entity_code and sd.customer = c.code
    join finance_dwh.dim_currency cur on sd.rep_currency = cur.code
    join finance_dwh.dim_product p on sd.product_name = p.name
    join finance_dwh.dim_calendar cal on cal.year = sd.year and cal.month = sd.period
    where not(sd.hfm_legal_entity = 'MO-SNGROUP' and sd.customer = 'MGT-Management Org')
    and c.lowest_hierarchy_level = true
    and cal.end_of_month_flag = true
    group by cal.id
    , c.id
    , cur.id
    , p.id;
    create temp table latest_fact_values as (
    select dim_calendar_id_period
    , dim_customer_id
    , dim_currency_id
    , dim_product_id
    , sum(actual_standard_see_through_gross_profit_net_of_all_adjustments) as actual_standard_see_through_gross_profit_net_of_all_adjustments
    , sum(actual_revenue_net_of_all_adjustments) as actual_revenue_net_of_all_adjustments
    , sum(actual_re_profit_net_of_all_adjustments) as actual_re_profit_net_of_all_adjustments
    from finance_dwh.fact_actual_revenue_monthly
    group by 1,2,3,4
    order by 1,2,3,4
    );
    insert into finance_dwh.fact_actual_revenue_monthly
    (dim_audit_id
    ,dim_calendar_id_effective
    , dim_calendar_id_period
    , dim_customer_id
    , dim_currency_id
    , dim_product_id
    , actual_standard_see_through_gross_profit_net_of_all_adjustments
    , actual_revenue_net_of_all_adjustments
    , actual_re_profit_net_of_all_adjustments)
    select (select id from audit_id)
    ,stg.dim_calendar_id_effective
    , stg.dim_calendar_id_period
    , stg.dim_customer_id
    , stg.dim_currency_id
    , stg.dim_product_id
    , stg.actual_standard_see_through_gross_profit_net_of_all_adjustments - isnull(lfv.actual_standard_see_through_gross_profit_net_of_all_adjustments, 0)
    , stg.actual_revenue_net_of_all_adjustments - isnull(lfv.actual_revenue_net_of_all_adjustments, 0)
    , stg.actual_re_profit_net_of_all_adjustments - isnull(lfv.actual_re_profit_net_of_all_adjustments, 0)
    from finance_dwh.stg_actual_revenue_monthly stg
    left join latest_fact_values lfv
    on stg.dim_calendar_id_period = lfv.dim_calendar_id_period
    and stg.dim_customer_id = lfv.dim_customer_id
    and stg.dim_currency_id = lfv.dim_currency_id
    and stg.dim_product_id = lfv.dim_product_id
    where lfv.dim_calendar_id_period is null -- New rows
    or stg.actual_standard_see_through_gross_profit_net_of_all_adjustments
        - isnull(lfv.actual_standard_see_through_gross_profit_net_of_all_adjustments, 0) <> 0
    or stg.actual_revenue_net_of_all_adjustments
        - isnull(lfv.actual_revenue_net_of_all_adjustments, 0) <> 0
    or stg.actual_re_profit_net_of_all_adjustments
        - isnull(lfv.actual_re_profit_net_of_all_adjustments, 0) <> 0;
    update finance_dwh.dim_audit set end_date = sysdate,
    rows_inserted = (select count(1) from finance_dwh.fact_actual_revenue_monthly where dim_audit_id = (select id from audit_id)),
    status = 'Finished'
    where id = (select id from audit_id);
    update finance_dwh.dim_audit set end_date = sysdate,
    rows_inserted = (select count(1) from finance_dwh.fact_actual_revenue_monthly where dim_audit_id = (select id from audit_id)),
    status = 'Finished'
    where id = (select id from audit_id);""".format(execution_id,
                                                    subprocess_name,
                                                    effective_date,
                                                    s3_output_path
                                                    )
    logger.info("Running {}".format(subprocess_name))
    write_data_to_redshift(glueContext,
                           execution_id,
                           subprocess_name,
                           redshift_tmp_dir,
                           actual_revenue_preaction_query,
                           actual_revenue_postaction_query)

    # Load budget
    subprocess_name = "budget_load"
    budget_preaction_query = "truncate table finance_dwh.raw_budget_monthly;"
    budget_postaction_query = """truncate table finance_dwh.stg_budget_monthly;
        create temp table audit_id as (select id from finance_dwh.dim_audit
        where execution_uuid = '{0}' and subprocess_name = '{1}');
        copy finance_dwh.raw_budget_monthly
        from '{3}version=Budget/'
        iam_role 'arn:aws:iam::783569832862:role/sni-dev-role'
        format as csv ignoreheader 1 gzip;
        insert into finance_dwh.stg_budget_monthly
        select
            {2} as dim_calendar_id_effective ,
            cal.id as dim_calendar_id_period ,
            c.id as dim_customer_id ,
            cur.id as dim_currency_id ,
            p.id as dim_product_id ,
            sum(case when measure = 'Standard See Through Gross Profit Net of All Adjustments' then isnull(amount, 0) else 0 end)
            as budget_standard_see_through_gross_profit_net_of_all_adjustments,
            sum(case when measure = 'Revenue Net of All Adjustments' then isnull(amount, 0) else 0 end) as budget_revenue_net_of_all_adjustments
        from (select distinct * from finance_dwh.raw_budget_monthly) sd
        join finance_dwh.dim_customer c on
            sd.hfm_legal_entity = c.entity_code
            and sd.customer = c.code
        join finance_dwh.dim_currency cur on
            sd.rep_currency = cur.code
        join finance_dwh.dim_product p on
            sd.product_name = p.name
        join finance_dwh.dim_calendar cal on
            cal.year = sd.year
            and cal.month = sd.period
        where
            not(sd.hfm_legal_entity = 'MO-SNGROUP' and sd.customer = 'MGT-Management Org')
            and c.lowest_hierarchy_level = true
            and cal.end_of_month_flag = true
        group by cal.id,c.id,cur.id,p.id;
        create temp table latest_fact_values as (
        select
            dim_calendar_id_period ,
            dim_customer_id ,
            dim_currency_id ,
            dim_product_id ,
            sum(budget_standard_see_through_gross_profit_net_of_all_adjustments) as budget_standard_see_through_gross_profit_net_of_all_adjustments ,
            sum(budget_revenue_net_of_all_adjustments) as budget_revenue_net_of_all_adjustments
        from finance_dwh.fact_budget_monthly
        group by 1,2,3,4
        order by 1,2,3,4);
        insert into finance_dwh.fact_budget_monthly
        (
            dim_audit_id,
            dim_calendar_id_effective,
            dim_calendar_id_period,
            dim_customer_id,
            dim_currency_id,
            dim_product_id,
            budget_standard_see_through_gross_profit_net_of_all_adjustments,
            budget_revenue_net_of_all_adjustments)
        select
            (select id from audit_id),
            stg.dim_calendar_id_effective,
            stg.dim_calendar_id_period,
            stg.dim_customer_id,
            stg.dim_currency_id,
            stg.dim_product_id,
            stg.budget_standard_see_through_gross_profit_net_of_all_adjustments
            - isnull(lfv.budget_standard_see_through_gross_profit_net_of_all_adjustments,0),
            stg.budget_revenue_net_of_all_adjustments
            - isnull(lfv.budget_revenue_net_of_all_adjustments,0)
        from finance_dwh.stg_budget_monthly stg
        left join latest_fact_values lfv on
            stg.dim_calendar_id_period = lfv.dim_calendar_id_period
            and stg.dim_customer_id = lfv.dim_customer_id
            and stg.dim_currency_id = lfv.dim_currency_id
            and stg.dim_product_id = lfv.dim_product_id
        where
            lfv.dim_calendar_id_period is null
            or isnull(stg.budget_standard_see_through_gross_profit_net_of_all_adjustments
            - lfv.budget_standard_see_through_gross_profit_net_of_all_adjustments, 0) <> 0
            or isnull(stg.budget_revenue_net_of_all_adjustments
            - lfv.budget_revenue_net_of_all_adjustments, 0) <> 0;
        update finance_dwh.dim_audit set end_date = sysdate,
        rows_inserted = (select count(1) from finance_dwh.fact_budget_monthly where dim_audit_id = (select id from audit_id)),
        status = 'Finished'
        where id = (select id from audit_id);""".format(execution_id,
                                                        subprocess_name,
                                                        effective_date,
                                                        s3_output_path
                                                        )
    logger.info("Running {}".format(subprocess_name))
    write_data_to_redshift(glueContext,
                           execution_id,
                           subprocess_name,
                           redshift_tmp_dir,
                           budget_preaction_query,
                           budget_postaction_query)
    # Load forecast
    subprocess_name = "forecast_load"
    forecast_preaction_query = "truncate table finance_dwh.raw_forecast_monthly;"
    forecast_postaction_query = """truncate table finance_dwh.stg_forecast_monthly;
        create temp table audit_id as (select id from finance_dwh.dim_audit
        where execution_uuid = '{0}' and subprocess_name = '{1}');
        copy finance_dwh.raw_forecast_monthly
        from '{3}version=Forecast/'
        iam_role 'arn:aws:iam::783569832862:role/sni-dev-role'
        format as csv ignoreheader 1 gzip;
        insert into finance_dwh.stg_forecast_monthly
        select {2} as dim_calendar_id_effective
        , cal.id as dim_calendar_id_period
        , c.id as dim_customer_id
        , cur.id as dim_currency_id
        , p.id as dim_product_id
        , sum(case when measure = 'Revenue Net of All Adjustments' 
            then isnull(amount, 0) else 0 end)
            as forecast_revenue_net_of_all_adjustments
        , sum(case when measure = 'Standard See Through Gross Profit Margin After All Adjustments'
            then isnull(amount, 0) else 0 end)
            as forecast_standard_see_through_gross_profit_margin_after_all_adjustments
        , sum(case when measure = 'Standard See Through Gross Profit Net of All Adjustments'
            then isnull(amount, 0) else 0 end)
            as forecast_standard_see_through_gross_profit_net_of_all_adjustments
        from (select distinct * from finance_dwh.raw_forecast_monthly) sd
        join finance_dwh.dim_customer c on sd.hfm_legal_entity = c.entity_code and sd.customer = c.code
        join finance_dwh.dim_currency cur on sd.rep_currency = cur.code
        join finance_dwh.dim_product p on sd.product_name = p.name
        join finance_dwh.dim_calendar cal on cal.year = sd.year and cal.month = sd.period
        where not(sd.hfm_legal_entity = 'MO-SNGROUP' and sd.customer = 'MGT-Management Org')
        and c.lowest_hierarchy_level = true
        and cal.end_of_month_flag = true
        group by cal.id
        , c.id
        , cur.id
        , p.id;
        create temp table latest_fact_values as (
        select dim_calendar_id_period
        , dim_customer_id
        , dim_currency_id
        , dim_product_id
        , sum(forecast_revenue_net_of_all_adjustments) 
            as forecast_revenue_net_of_all_adjustments
        , sum(forecast_standard_see_through_gross_profit_margin_after_all_adjustments) 
            as forecast_standard_see_through_gross_profit_margin_after_all_adjustments
        , sum(forecast_standard_see_through_gross_profit_net_of_all_adjustments) 
            as forecast_standard_see_through_gross_profit_net_of_all_adjustments
        from finance_dwh.fact_forecast_monthly
        group by 1,2,3,4
        order by 1,2,3,4
        );
        insert into finance_dwh.fact_forecast_monthly
        (dim_audit_id
        ,dim_calendar_id_effective
        ,dim_calendar_id_period
        ,dim_customer_id
        ,dim_currency_id
        ,dim_product_id
        ,forecast_revenue_net_of_all_adjustments
        ,forecast_standard_see_through_gross_profit_margin_after_all_adjustments
        ,forecast_standard_see_through_gross_profit_net_of_all_adjustments)
        select (select id from audit_id)
        , stg.dim_calendar_id_effective
        , stg.dim_calendar_id_period
        , stg.dim_customer_id
        , stg.dim_currency_id
        , stg.dim_product_id
        , stg.forecast_revenue_net_of_all_adjustments - isnull(lfv.forecast_revenue_net_of_all_adjustments, 0)
        , stg.forecast_standard_see_through_gross_profit_margin_after_all_adjustments
        - isnull(lfv.forecast_standard_see_through_gross_profit_margin_after_all_adjustments, 0)
        , stg.forecast_standard_see_through_gross_profit_net_of_all_adjustments
        - isnull(lfv.forecast_standard_see_through_gross_profit_net_of_all_adjustments, 0)
        from finance_dwh.stg_forecast_monthly stg
        left join latest_fact_values lfv
        on stg.dim_calendar_id_period = lfv.dim_calendar_id_period
        and stg.dim_customer_id = lfv.dim_customer_id
        and stg.dim_currency_id = lfv.dim_currency_id
        and stg.dim_product_id = lfv.dim_product_id
        where lfv.dim_calendar_id_period is null -- New rows
        or stg.forecast_revenue_net_of_all_adjustments
            - isnull(lfv.forecast_revenue_net_of_all_adjustments, 0) <> 0
        or stg.forecast_standard_see_through_gross_profit_margin_after_all_adjustments
            - isnull(lfv.forecast_standard_see_through_gross_profit_margin_after_all_adjustments, 0) <> 0
        or stg.forecast_standard_see_through_gross_profit_net_of_all_adjustments
            - isnull(lfv.forecast_standard_see_through_gross_profit_net_of_all_adjustments, 0) <> 0;
        update finance_dwh.dim_audit set end_date = sysdate,
        rows_inserted = (select count(1) from finance_dwh.fact_forecast_monthly
        where dim_audit_id = (select id from audit_id)),
        status = 'Finished'
        where id = (select id from audit_id);""".format(execution_id,
                                                        subprocess_name,
                                                        effective_date,
                                                        s3_output_path
                                                        )
    logger.info("Running {}".format(subprocess_name))
    write_data_to_redshift(glueContext,
                           execution_id,
                           subprocess_name,
                           redshift_tmp_dir,
                           forecast_preaction_query,
                           forecast_postaction_query)
