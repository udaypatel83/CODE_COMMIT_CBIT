import sys

from pyspark.context import SparkContext

from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions

glueContext = GlueContext(SparkContext.getOrCreate())
job = Job(glueContext)

args = getResolvedOptions(sys.argv,
                          ["JOB_NAME",
                           "debug_mode",
                           "s3_file",
                           "s3_output_path"])
job.init(args['JOB_NAME'], args)

s3_file = args["s3_file"].split(",")
debug_mode = args["debug_mode"]
s3_output_path = args["s3_output_path"]

if debug_mode:
    print("s3_file:", s3_file)
    print("s3_output_path:", s3_output_path)

# Load the CSV file into a frame
csv_df = glueContext.create_dynamic_frame_from_options("s3", {"paths": s3_file},
                                                       format="csv",
                                                       format_options={"withHeader": True})
if debug_mode:
    csv_df.printSchema()

mappings = [("Version", "string", "version", "string"),
            ("Year", "string", "year", "long"),
            ("Period", "string", "period", "long"),
            ("HFM Legal Entity", "string", "hfm_legal_entity", "string"),
            ("Rep Currency", "string", "rep_currency", "string"),
            ("Customer", "string", "customer", "string"),
            ("Product Code", "string", "product_code", "string"),
            ("Product Name", "string", "product_name", "string"),
            ("Data", "string", "data", "string"),
            ("Measure", "string", "measure", "string"),
            ("Amount", "string", "amount", "float")]

csv_fields = [f.name for f in csv_df.schema().fields]
mapping_fields = [m[0] for m in mappings]
if csv_fields != mapping_fields:
    raise ValueError("Source fields differ to the defined schema! \n"
                     "{0}\n instead of \n{1}".format(csv_fields, mapping_fields))

# Rename the columns in the CSV file to match the Redshift table columns, otherwise they will be added as new columns.
renamed_df = csv_df.apply_mapping(mappings=mappings)

if debug_mode:
    renamed_df.printSchema()
    print("Writing output to:", s3_output_path)

# Write the file to S3 partitioned on the version in GZIP format.
glueContext.write_dynamic_frame.from_options(frame=renamed_df,
                                             connection_type="s3",
                                             connection_options={"path": s3_output_path,
                                                                 "compression": "gzip",
                                                                 "partitionKeys": ["version"]},
                                             format="csv")
