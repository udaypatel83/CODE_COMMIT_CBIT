import sys
from datetime import datetime

from pyspark.context import SparkContext

from awsglue.context import GlueContext
from awsglue.dynamicframe import DynamicFrame
from awsglue.job import Job
from awsglue.utils import getResolvedOptions

glueContext = GlueContext(SparkContext.getOrCreate())
job = Job(glueContext)

args = getResolvedOptions(sys.argv,
                          ["JOB_NAME",
                           "debug_mode",
                           "s3_file",
                           "target_database",
                           "raw_table",
                           "staging_table",
                           "fact_table",
                           "redshift_tmp_dir"])
job.init(args['JOB_NAME'], args)

s3_file = args["s3_file"].split(",")
target_database = args["target_database"]
raw_table = args["raw_table"]
staging_table = args["staging_table"]
fact_table = args["fact_table"]
redshift_tmp_dir = args["redshift_tmp_dir"]
debug_mode = args["debug_mode"]

if debug_mode:
    print(s3_file)

csv_df = glueContext.create_dynamic_frame_from_options(connection_type="s3",
                                                       connection_options={"paths": s3_file,
                                                                           "compressionType": "gzip"},
                                                       format="csv",
                                                       format_options={"withHeader": True})
if debug_mode:
    csv_df.printSchema()

finance_df = csv_df.resolveChoice(specs=[('year', 'cast:long'), ('period', 'cast:long'), ('amount', 'cast:double')])

if debug_mode:
    finance_df.printSchema()

# s3_file = "s3://sni-s02-tm1-source-data/SGTP_HFM_Planning/CBIT_STGP_HFM_Planning_2017.csv"
# target_database = "sni"
# raw_table = "tm1.raw_sgtp_hfm_planning"
# staging_table = "tm1.stg_fact_finance"
# fact_table = "tm1.fact_finance_test"
# redshift_tmp_dir = "s3://aws-glue-temporary-783569832862-us-east-2/"

now = datetime.now()
effective_date = now.strftime("%Y%m%d")

# This will run before the COPY operation
preaction_query = "TRUNCATE TABLE {0};".format(raw_table)

# This will run after the COPY operation
postaction_query = """TRUNCATE TABLE {0};
insert into {0}
select {3} as dim_calendar_id_effective
, cal.id as dim_calendar_id_period
, c.id as dim_customer_id
, cur.id as dim_currency_id
, p.id as dim_product_id
, sum(case when measure = 'Revenue Net of All Adjustments' 
    then isnull(amount, 0) else 0 end) 
    as forecast_revenue_net_of_all_adjustments
, sum(case when measure = 'Standard See Through Gross Profit Margin After All Adjustments' 
    then isnull(amount, 0) else 0 end) 
    as forecast_standard_see_through_gross_profit_margin_after_all_adjustments
, sum(case when measure = 'Standard See Through Gross Profit Net of All Adjustments' 
    then isnull(amount, 0) else 0 end) 
    as forecast_standard_see_through_gross_profit_net_of_all_adjustments
from {1} sd
 join finance_dwh.dim_customer c on sd.hfm_legal_entity = c.entity_code and sd.customer = c.code
 join finance_dwh.dim_currency cur on sd.rep_currency = cur.code
 join finance_dwh.dim_product p on sd.product_name = p.name
 join finance_dwh.dim_calendar cal on cal.year = sd.year and cal.month = sd.period
where not(sd.hfm_legal_entity = 'MO-SNGROUP' and sd.customer = 'MGT-Management Org')
and c.lowest_hierarchy_level = true
and cal.end_of_month_flag = true
group by cal.id
, c.id
, cur.id
, p.id;
create temp table latest_fact_values as (
select dim_calendar_id_period
, dim_customer_id
, dim_currency_id
, dim_product_id
, sum(forecast_revenue_net_of_all_adjustments) 
    as forecast_revenue_net_of_all_adjustments
, sum(forecast_standard_see_through_gross_profit_margin_after_all_adjustments) 
    as forecast_standard_see_through_gross_profit_margin_after_all_adjustments
, sum(forecast_standard_see_through_gross_profit_net_of_all_adjustments) 
    as forecast_standard_see_through_gross_profit_net_of_all_adjustments
from {2}
group by 1,2,3,4
order by 1,2,3,4
);
insert into {2}
(dim_calendar_id_effective
, dim_calendar_id_period
, dim_customer_id
, dim_currency_id
, dim_product_id
, forecast_revenue_net_of_all_adjustments
, forecast_standard_see_through_gross_profit_margin_after_all_adjustments
, forecast_standard_see_through_gross_profit_net_of_all_adjustments)
select stg.dim_calendar_id_effective
, stg.dim_calendar_id_period
, stg.dim_customer_id
, stg.dim_currency_id
, stg.dim_product_id
, stg.forecast_revenue_net_of_all_adjustments - isnull(lfv.forecast_revenue_net_of_all_adjustments, 0)
, stg.forecast_standard_see_through_gross_profit_margin_after_all_adjustments - isnull(lfv.forecast_standard_see_through_gross_profit_margin_after_all_adjustments, 0)
, stg.forecast_standard_see_through_gross_profit_net_of_all_adjustments - isnull(lfv.forecast_standard_see_through_gross_profit_net_of_all_adjustments, 0)
from {0} stg
left join latest_fact_values lfv
on stg.dim_calendar_id_period = lfv.dim_calendar_id_period
and stg.dim_customer_id = lfv.dim_customer_id
and stg.dim_currency_id = lfv.dim_currency_id
and stg.dim_product_id = lfv.dim_product_id
where lfv.dim_calendar_id_period is null -- New rows
or stg.forecast_revenue_net_of_all_adjustments 
    - isnull(lfv.forecast_revenue_net_of_all_adjustments, 0) <> 0
or stg.forecast_standard_see_through_gross_profit_margin_after_all_adjustments 
    - isnull(lfv.forecast_standard_see_through_gross_profit_margin_after_all_adjustments, 0) <> 0
or stg.forecast_standard_see_through_gross_profit_net_of_all_adjustments 
    - isnull(lfv.forecast_standard_see_through_gross_profit_net_of_all_adjustments, 0) <> 0
""".format(staging_table, raw_table, fact_table, effective_date)

if debug_mode:
    print(preaction_query)
    print(postaction_query)

if debug_mode:
    print("Repartitioning...")
df = finance_df.toDF().repartition(4)
dyn_df = DynamicFrame.fromDF(df, glueContext, "myframe")

# Load file into Redshift from S3
if debug_mode:
    print("Writing to Redshift...")
glueContext.write_dynamic_frame.from_jdbc_conf(frame=dyn_df,
                                               catalog_connection="redshift-sni-dev",
                                               connection_options={"preactions": preaction_query,
                                                                   "dbtable": raw_table,
                                                                   "database": target_database,
                                                                   "postactions": postaction_query},
                                               redshift_tmp_dir=redshift_tmp_dir
                                               )
