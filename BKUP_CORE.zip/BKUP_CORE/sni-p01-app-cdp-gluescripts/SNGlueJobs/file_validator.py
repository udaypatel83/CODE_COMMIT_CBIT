import sys

import boto3
from pyspark.context import SparkContext

from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions

glueContext = GlueContext(SparkContext.getOrCreate())
job = Job(glueContext)
glue_client = boto3.client("glue", region_name="us-east-2")

args = getResolvedOptions(sys.argv,
                          ["JOB_NAME",
                           "glue_database",
                           "s3_file",
                           "raw_table"])
job.init(args['JOB_NAME'], args)

s3_file = args["s3_file"].split(",")
glue_database = args["glue_database"]
raw_table = args["raw_table"]

# Load the CSV file into a frame
csv_df = glueContext.create_dynamic_frame_from_options(connection_type="s3",
                                                       connection_options={"paths": s3_file,
                                                                           "compressionType": "gzip"},
                                                       format="csv",
                                                       format_options={"withHeader": True})

mappings = [("Version123", "string", "version", "string"),
            ("Year", "string", "year", "long"),
            ("Period", "string", "period", "long"),
            ("HFM Legal Entity", "string", "hfm_legal_entity", "string"),
            ("Rep Currency", "string", "rep_currency", "string"),
            ("Customer", "string", "customer", "string"),
            ("Product Code", "string", "product_code", "string"),
            ("Product Name", "string", "product_name", "string"),
            ("Data", "string", "data", "string"),
            ("Measure", "string", "measure", "string"),
            ("Amount", "string", "amount", "float")]

csv_fields = [f.name for f in csv_df.schema().fields]
mapping_fields = [m[0] for m in mappings]
if csv_fields != mapping_fields:
    raise ValueError("Source fields differ to the defined schema! \n"
                     "{0}\n instead of \n{1}".format(csv_fields, mapping_fields))

# Rename the columns in the CSV file to match the Redshift table columns, otherwise they will be added as new columns.
renamed_df = csv_df.apply_mapping(mappings=mappings)

data_source = glueContext.getSource(connection_type="redshift", )
