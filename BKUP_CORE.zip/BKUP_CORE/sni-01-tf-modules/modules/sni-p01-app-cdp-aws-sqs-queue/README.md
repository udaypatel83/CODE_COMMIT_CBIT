# Module `sni-p01-app-cdp-aws-sqs-queue`

Module to create a SQS queue.

Provider Requirements:

- **aws:** (2.20)

## Input Variables

- `encrypt_kms_key` (required): KMS key alias to encrypt the contents with. optional.
- `queue_name` (required): SQS queue name. optional.
- `sns_topic_subscribe` (default `true`): create a subscription for the upstream SNS topic
- `source_sns_topic_arn` (required): Source SNS topic arn to subscribe to
- `sqs_fifo_queue` (default `true`): Whether to use a FIFO queue for SQS
- `sqs_message_delay_seconds` (required): Seconds to delay all messages in the queue (0 to 900)
- `sqs_message_retention_seconds` (default `604800`): number of seconds to keep messages in the queue (default 7 days)
- `sqs_queue_create` (default `true`): Whether to create the queue or not
- `tags` (required): Tags. optional.

## Output Values

- `arn`
- `id`

## Managed Resources

- `aws_sns_topic_subscription.sns_topic_subscription` from `aws`
- `aws_sqs_queue.sqs_queue` from `aws`
- `aws_sqs_queue_policy.sqs_queue_policy` from `aws`

## Data Resources

- `data.aws_iam_policy_document.sqs_policy` from `aws`
