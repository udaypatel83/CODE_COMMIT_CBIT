<powershell>
#As of today, PowerBI data gateway cannot be installed silently or the installation does not seem to be automatable.
#https://community.powerbi.com/t5/Desktop/On-premises-data-gateway-silent-install/td-p/304047

#This Step is therefore done manually
</powershell>