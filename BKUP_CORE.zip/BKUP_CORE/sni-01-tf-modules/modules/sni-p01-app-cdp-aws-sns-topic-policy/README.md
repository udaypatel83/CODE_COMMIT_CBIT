
# Module `sni-p01-app-cdp-aws-sns-topic-policy`

Provider Requirements:
* **aws:** (any version)

## Input Variables
* `encrypt_kms_key` (required): KMS key alias to encrypt the contents with. optional.
* `source_arns` (required): List of source ARNs to allow publication to this topic.
* `topic_arn` (required): SNS topic ARN
* `topic_name` (required): SNS topic name

## Managed Resources
* `aws_sns_topic_policy.sns_topic_policy` from `aws`

## Data Resources
* `data.aws_iam_policy_document.iam_policy_sns_topic` from `aws`

