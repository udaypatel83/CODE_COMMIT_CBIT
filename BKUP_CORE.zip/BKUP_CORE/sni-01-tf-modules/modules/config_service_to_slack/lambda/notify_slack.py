from __future__ import print_function
import os, boto3, json, base64
import urllib.request, urllib.parse, logging, dateutil.parser


# Decrypt encrypted URL with KMS
def decrypt(encrypted_url):
    region = os.environ['AWS_REGION']
    try:
        kms = boto3.client('kms', region_name=region)
        plaintext = kms.decrypt(CiphertextBlob=base64.b64decode(encrypted_url))['Plaintext']
        return plaintext.decode()
    except Exception:
        logging.exception("Failed to decrypt URL with KMS")


def default_notification(subject, message):
    alert_type = message['detail-type']
    region = message['detail']['awsRegion']
    account_number = message['detail']['awsAccountId']
    triggered_rule = message['detail']['configRuleName']
    resource_type = message['detail']['resourceType']
    resource_id = message['detail']['resourceId']
    last_seen = dateutil.parser.parse(message['time']).strftime('%a, %d %b %Y %H:%M:%S')
    newStatus = message['detail']['newEvaluationResult']['complianceType']
    oldStatus = message['detail']['oldEvaluationResult']['complianceType']
    
    return {
            "color": "warning",
            "fallback": f"Config rule {triggered_rule} triggered\nAccount: {account_number}\nResource: {resource_type}\t{resource_id}",
            "title": alert_type,
            "title_link": f"https://us-east-2.console.aws.amazon.com/config/home?region=us-east-2#/rules/view?filter=%7B%22compliance%22:%7B%22key%22:%22nonCompliant%22,%22value%22:%22NON_COMPLIANT%22,%22text%22:%22Noncompliant%22%7D%7D",
            "fields": [
                {
                    "title": "Resource type",
                    "value": resource_type,
                    "short": True
                },
                {
                    "title": "Resource ID",
                    "value": resource_id,
                    "short": True
                },
                {
                    "title": "Region",
                    "value": region,
                    "short": True
                },
                {
                    "title": "Rule",
                    "value": triggered_rule,
                    "short": True
                },
                {
                    "title": "Last Seen",
                    "value": last_seen,
                    "short": True
                },
                {
                    "title": "Compliance Status",
                    "value": f"{oldStatus} -> {newStatus}",
                    "short": True
                }
            ]
        }


# Send a message to a slack channel
def notify_slack(subject, message, region):
    slack_url = os.environ['SLACK_WEBHOOK_URL']
    if not slack_url.startswith("http"):
        slack_url = decrypt(slack_url)

    slack_channel = os.environ['SLACK_CHANNEL']
    slack_username = os.environ['SLACK_USERNAME']
    slack_emoji = os.environ['SLACK_EMOJI']

    payload = {
        "channel": slack_channel,
        "username": slack_username,
        "icon_emoji": slack_emoji,
        "attachments": []
    }

    payload['text'] = f"*Finding in {message['detail']['awsRegion']} for Acct: {message['detail']['awsAccountId']}*"
    payload['attachments'].append(default_notification(subject, message))

    data = urllib.parse.urlencode({"payload": json.dumps(payload)}).encode("utf-8")
    req = urllib.request.Request(slack_url)
    urllib.request.urlopen(req, data)


def lambda_handler(event, context):
    subject = event['Records'][0]['Sns']['Subject']
    message = event['Records'][0]['Sns']['Message']
    region = event['Records'][0]['Sns']['TopicArn'].split(":")[3]

    # Only send alert when resource becomes non-compliant
    if message['detail']['newEvaluationResult']['complianceType'] == "NON_COMPLIANT":
        notify_slack(subject, message, region)
        return message
    else:
        return None
