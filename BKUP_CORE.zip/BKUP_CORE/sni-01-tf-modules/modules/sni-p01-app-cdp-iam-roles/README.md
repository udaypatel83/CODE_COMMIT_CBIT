# sni-p01-app-cdp-iam-roles

Module to create roles specific to the Cloud Data Platform accounts.
These roles are used by IAM users that have the right grant to assume them in the provisioning account.

## usage

```hcl
module "iamroles" {
  providers = {
    aws = aws.aws-assume
  }
  source                     = "../modules/sni-p01-app-cdp-iam-roles"
  iam_roles_description      = var.iam_roles_description
  iam_roles_map_policies_aws = var.iam_roles_map_policies_aws
}

variable "iam_roles_description" {
  default = {
    "CDP-DataEngineers" = "Role for Data Engineers in the Cloud Data Platform team"
    "CDP-QA"            = "Role for QA Testers in the Cloud Data Platform team"
  }
}

variable "iam_roles_map_policies_aws" {
  default = {
    "AmazonS3ReadOnlyAccess"       = ["CDP-DataEngineers", "CDP-QA"]
    "AWSCodeCommitReadOnly"        = ["CDP-DataEngineers", "CDP-QA"]
    "AWSGlueConsoleFullAccess"     = ["CDP-DataEngineers", "CDP-QA"]
    "AmazonRedshiftReadOnlyAccess" = ["CDP-DataEngineers"]
  }
}
```

## Inputs

| Name                       | Description                                                                            |  Type  | Default | Required |
| -------------------------- | -------------------------------------------------------------------------------------- | :----: | :-----: | :------: |
| account_id                 | Source Account ID for the role trust relationship. Defaults to current if not provided | string |  `""`   |    no    |
| iam_roles_description      | map of names to descriptions                                                           |  map   | `<map>` |    no    |
| iam_roles_map_policies_aws | map of policies to a list of role names                                                |  map   | `<map>` |    no    |
