# Module `sni-p01-app-cdp-aws-lambda-layer`

This module adds lambda layers (common functions reusable across different lambdas)

Provider Requirements:

- **aws:** (2.20+)

## Input Variables

- `lambda_layer` (required): map of objects describing lambda layers

```
variable "lambda_layer" {
  description = "map of objects describing lambda layers"
  type = map(object({
    filename   = string
    layer_name = string
    runtimes   = list(string)
  }))
}
```

The key name in the map matches the name of the zip archive into the `lambda_layers` directory.

## notes

The current terraform container lacks the 'archive' provider to be able to zip the content
of the function on the fly, therefore the module needs to have the function pre-zipped
Please note that different language require different structure in the zip file,
For example python requires the function to be provided as `python/layer.py` in the zip.

The structure of files inside the zip file is made before terraform by the user.
Different languages require different paths: [AWS documentation](https://docs.aws.amazon.com/lambda/latest/dg/API_PublishLayerVersion.html#SSS-PublishLayerVersion-request-CompatibleRuntimes)
In the case of python, just put `layer.py` inside a `python/` subdirectory

## example

```

variable "lambda_layer" {
  default = {
    decrypt_ssm_parameters_from_path = {
      filename   = "ssm_path_read.py"
      layer_name = "ssm_path_read"
      runtimes   = ["python3.6"]
    }
    cloudwatch_metrics = {
      filename   = "cloudwatch_metrics.py"
      layer_name = "cloudwatch_metrics"
      runtimes   = ["python3.6"]
    }
  }
}
```

## Output Values

- `arn`: ARN (with version)
- `layer_arn`: ARN (without version)
- `layer_name`: Layer name

## Managed Resources

- `aws_lambda_layer_version.lambda_layer` from `aws`
