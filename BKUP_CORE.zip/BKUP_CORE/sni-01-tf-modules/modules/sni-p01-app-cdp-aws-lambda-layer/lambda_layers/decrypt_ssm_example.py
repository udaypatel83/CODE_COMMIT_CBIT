'''
  this is useful to decrypt a value passed as ENV variable.
'''
import boto3
import os

from base64 import b64decode

ENCRYPTED = os.environ['foo']
# Decrypt code should run once and variables stored outside of the function
# handler so that these are decrypted once per container
DECRYPTED = boto3.client('kms').decrypt(CiphertextBlob=b64decode(ENCRYPTED))['Plaintext'].decode("utf-8")

def lambda_handler(event, context):
    return DECRYPTED 