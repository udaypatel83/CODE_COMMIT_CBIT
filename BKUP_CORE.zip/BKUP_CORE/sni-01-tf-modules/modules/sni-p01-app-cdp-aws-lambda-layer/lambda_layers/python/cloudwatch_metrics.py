'''
function to put a cloudwatch metric
'''

import boto3

cloudwatch = boto3.client('cloudwatch')

def put_metric(namespace,metricname,metricvalue,dimensions):
  dimensions = 
  response = cloudwatch.put_metric_data(
      MetricData = [
          {
              'MetricName': metricname,
              'Dimensions': [ { 'Name': k, 'Value': v} for k, v in dimensions.items() ],
              'Unit': 'None',
              'Value': metricvalue
          },
      ],
      Namespace = namespace
  )
  return response
