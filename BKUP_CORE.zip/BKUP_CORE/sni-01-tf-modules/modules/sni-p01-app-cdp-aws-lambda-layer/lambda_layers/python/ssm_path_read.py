"""
    get a dictionary with all the parameters under a specific path.
    it requires a IAM role in place to read from SSM and possibly
    access to the KMS key parameters are encrypted with.

    use by:
        parameters=get_config_by_path(ssm_ppath)
    
    return:
        config=dict() of key value parameters under ssm path

"""

import os,sys
import boto3

ssm = boto3.client('ssm')

def get_config_by_path(ssm_parameter_path,decrypt=True,strippath=True):
     # Get all parameters by path
    param_details = ssm.get_parameters_by_path(
        Path=ssm_parameter_path,
        Recursive=False,
        WithDecryption=decrypt
    )
    config=dict()
    
    if 'Parameters' in param_details and len(param_details.get('Parameters')) > 0:
        for param in param_details.get('Parameters'):
            k=param.get('Name')
            k=k[len(ssm_parameter_path)+1:] if k.startswith(ssm_parameter_path) else k
            config.update({k: param.get('Value')})
    return config


