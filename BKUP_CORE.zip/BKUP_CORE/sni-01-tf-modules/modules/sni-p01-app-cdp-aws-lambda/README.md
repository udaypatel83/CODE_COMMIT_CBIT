# Module `sni-p01-app-cdp-aws-lambda`

Module to provision a lambda with IAM roles attached.

Provider Requirements:

- **archive:** (any version)
- **aws:** (any version)

## Input Variables

- `kms_key_id` (required): KMS key ID (not alias) to encrypt the contents with. optional.
- `lambda_environment_variables` (required): map of environment variables to assign to the function
- `lambda_filename` (required): Filename relative to the 'lambda_functions' subdirectory (the output filename will be renamed to function name)
- `lambda_function_handler` (required): Name of the function script that handles the lambda execution
- `lambda_function_name` (required): Name to assign to the function. It will be also the filename localpart (as per AWS lambda rules)
- `lambda_layer_arns` (required): list of lambda layer ARNs to attach to the function. optional.
- `lambda_memory_size` (default `1024`): memory to allocate to lambda execution
- `lambda_runtime_language` (default `"python2.7"`): Lambda runtime language
- `lambda_timeout` (default `5`): lambda execution timeout
- `sqs_batch_size` (default `1`): how many SQS events for a lambda to trigger
- `sqs_queue_arn` (required): SQS queue arn to attach to the function
- `ssm_parameters` (required): list of SSM parameters to pass to the function (extra to ssm_parameters_path)
- `ssm_parameters_path` (required): read all parameters under this path.
- `tags` (required): Tags. optional.
- `vpc_security_group_ids` (required): list of security groups of the VPC to attach to
- `vpc_subnet_ids` (required): list of subnets of the VPC to assign to

## Output Values

- `arn`

## Managed Resources

- `aws_iam_policy.iam_policy_kms` from `aws`
- `aws_iam_policy.iam_policy_sqs` from `aws`
- `aws_iam_policy.iam_policy_ssm_parameters` from `aws`
- `aws_iam_policy.iam_policy_ssm_path` from `aws`
- `aws_iam_role.lambda_iam_role` from `aws`
- `aws_iam_role_policy_attachment.iam_policy_attachment_aws` from `aws`
- `aws_iam_role_policy_attachment.iam_policy_attachment_lambda_kms` from `aws`
- `aws_iam_role_policy_attachment.iam_policy_attachment_lambda_sqs` from `aws`
- `aws_iam_role_policy_attachment.iam_policy_attachment_lambda_ssm_parameters` from `aws`
- `aws_iam_role_policy_attachment.iam_policy_attachment_ssm_path` from `aws`
- `aws_lambda_event_source_mapping.event_source_mapping` from `aws`
- `aws_lambda_function.lambda` from `aws`

## Data Resources

- `data.archive_file.lambda_archive` from `archive`
- `data.aws_caller_identity.current` from `aws`
- `data.aws_iam_policy_document.assumerole_policy` from `aws`
- `data.aws_iam_policy_document.iam_policy_document_kms` from `aws`
- `data.aws_iam_policy_document.iam_policy_document_sqs` from `aws`
- `data.aws_iam_policy_document.iam_policy_document_ssm_parameters` from `aws`
- `data.aws_iam_policy_document.iam_policy_document_ssm_path` from `aws`
- `data.aws_region.current` from `aws`

## notes

The module can be used together with the `sni-p01-app-cdp-aws-lambda-layers` module to have dependant layers attached.
To specify a specific version of a layer, append it to the name, ie `layer:3`

## example

```hcl
// [..]
// omitting dependant configs like sqs etc..


locals {
  lambda_layer_arns = matchkeys(
    module.lambda_layers.arn,
    module.lambda_layers.layer_name,
    var.lambda_layer_names
}

variable "lambda_layer" {
  default = {
    decrypt_ssm_parameters_from_path = {
      filename   = "ssm_path_read.py"
      layer_name = "decrypt_ssm_path"
      runtimes   = ["python2.7"]
    }
  }
}

variable "lambda_layer_names" {
  default = ["decrypt_ssm_path"]
}

module "lambda_layers" {
  providers = {
    aws = aws.aws-assume
  }
  source       = "../modules/sni-p01-app-cdp-aws-lambda-layer"
  lambda_layer = var.lambda_layer
}


// lambda function to send notifications
module "lambda_notification" {
  providers = {
    aws = aws.aws-assume
  }
  source               = "../modules/sni-p01-app-cdp-aws-lambda"
  lambda_function_name = "slack_notification"
  lambda_filename      = "lambda_slack_notification.py"
  // this value is computed from the lambda_layers module
  lambda_layer_arns   = local.lambda_layer_arns
  ssm_parameters_path = "/783569832862/slack_notification"
  sqs_queue_arn       = module.sqs_queue_slack.arn
  tags                = local.tags
}
```
