from __future__ import print_function
import os, boto3, json
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO) # change to DEBUG for debugging
import ssm_path_read as ssm
# Decrypt encrypted URL with KMS
config = ssm.get_config_by_path(os.environ['ssm_parameters_path'])

glueclient = boto3.client('glue')

responses=list()

def lambda_handler(event, context):
    logging.info('Event source: {}'.format(event))
    logging.debug(str(config))
    
    job_name=''
    job_args=json.loads(config['lambda_glue_job_args']) # job>args
    job_map=json.loads(config['lambda_glue_job_map']) # bucket>gluejob
    
    logging.debug("Job map: {}".format(job_map))
    logging.debug("Job args: {}".format(job_args))
    
    for record in event['Records']:
        region = record['awsRegion']

        ''' SQS gives the actual message encapsulated in a body envelope '''
        body=json.loads(record['body'])
        logging.debug("Body: {}".format(body))

        '''
         We are only interested in s3 bucket notifications
         for triggering glue jobs
        '''
        if body['Subject'] == 'Amazon S3 Notification':
          message=json.loads(body['Message'])
          logging.debug("Message: {}".format(message))
          ''' the Records definition comes as encapsulated again '''
          if 'Records' in message.keys():
              for record in message['Records']:
                process_record(record,job_map,job_args)
          else:
              process_record(message,job_map,job_args)
    
    return responses

def process_record(record,job_map,job_args):
    if 'Event' in record.keys():
        if record['Event'] == 's3:TestEvent':
            return

    s3bucket=record['s3']['bucket']['name']
    s3object=record['s3']['object']['key']
    logging.debug("s3 bucket found: {} obj: {}".format(s3bucket,s3object))
    
    ''' check if there's a matching job '''
    if s3bucket in job_map.keys():
        job_name=job_map[s3bucket]
        ''' check if there's a matching job argument definition '''
        if job_name in job_args.keys():
            if 's3_input_file' in job_args[job_name]:
                job_args[job_name]['s3_input_file']=s3object
            
            logging.info("Starting job: {} with arguments: {} from bucket {} with object {}".format(job_name,job_args[job_name],s3bucket,s3object))
            response = glueclient.start_job_run(
                JobName = job_name,
                Arguments = job_args[job_name] )
            responses.append(response)
        else:
            logging.exception('No job found by bucket {}'.format(s3bucket))            
    else:
        logging.exception('No bucket definition found for bucket {}'.format(s3bucket))