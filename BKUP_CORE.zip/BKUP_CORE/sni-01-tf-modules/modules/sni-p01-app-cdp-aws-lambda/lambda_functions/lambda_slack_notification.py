from __future__ import print_function
import os, boto3, json, base64
import urllib.request, urllib.parse
import ssm_path_read as ssm
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Decrypt encrypted URL with KMS
config = ssm.get_config_by_path(os.environ['ssm_parameters_path'])


def default_notification(subject, message):
    return {
            "fallback": "A new message",
            "fields": [{"title": subject, "value": message, "short": False}]
        }


# Send a message to a slack channel
def notify_slack(title, subject, message, region):
    slack_url = config['slack_webhook_url']

    slack_channel = config['slack_channel']
    slack_username = "SNI-CloudDataPlatform-bot"
    slack_emoji = ":rotating_light:"

    payload = {
        "channel": slack_channel,
        "username": slack_username,
        "icon_emoji": slack_emoji,
        "attachments": []
    }

    payload['text'] = title 
    payload['attachments'].append(default_notification(subject, message))

    data = urllib.parse.urlencode({"payload": json.dumps(payload)}).encode("utf-8")
    req = urllib.request.Request(slack_url)
    urllib.request.urlopen(req, data)


def lambda_handler(event, context):
    logging.info('Event source: {}'.format(event))
    responses=list()
    for record in event['Records']:
        ''' SQS give the actual message encapsulated in a body envelope '''

        region = record['awsRegion']

        body=json.loads(record['body'])

        title=body['detail-type']
        subject = body['detail']['message']
        message = "Job ID: {}\nJob Name: {}".format(body['detail']['jobRunId'],body['detail']['jobName'])
        
        notify_slack(title, subject, message, region)
        responses.append(body)
    
    return responses