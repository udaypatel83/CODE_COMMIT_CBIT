
# Module `sni-p01-app-cdp-aws-bucket-object`

Provider Requirements:
* **aws:** (any version)

## Input Variables
* `bucket_name` (required): Bucket name
* `encrypt_kms_key` (required): KMS key alias to encrypt the contents with. optional.
* `objects` (required): a list of files to upload relative to var.path
* `path` (required): Local/Source Path to files to upload. Defaults to current working directory
* `prefix` (required): Prefix path relative to bucket root
* `tags` (required): Tags. optional.

## Output Values
* `uploaded_files`

## Managed Resources
* `aws_s3_bucket_object.s3_bucket_object` from `aws`

