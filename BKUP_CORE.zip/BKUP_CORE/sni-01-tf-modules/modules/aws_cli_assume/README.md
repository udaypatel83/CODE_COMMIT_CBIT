(Borrowed from https://github.com/opetch/terraform-aws-cli-resource)

AWS CLI Resource Terraform Module
=================================

This module is used to create a AWS resource in terraform by calling out to the CLI, with support for cross account resource creation (see example). The module encapsulates the act of assuming a role, when required to create the resource in the specified account. 

Prerequisites
-------------
 * Must be using sts assume role as a means to authenticate (where a role is supplied).
 * The credentials terraform is using to run must resolve to a identity with permissions allowing assuming of the roles the module is configured to use (where a role is supplied).
 * `cksum`, `grep`, `awk` must be available (as they are on most systems)

```hcl
locals {
  cli_flags = "--hosted-zone-id SOME_HOSTEDZONEID --vpc VPCRegion=eu-west-1,VPCId=vpc-abc123xyz"
}

module "create_vpc_association_authorization" {
  source = "../../cli_resource"

  account_id      = "123456789" # Account with the private hosted zone
  role            = "TF_Role"
  cmd             = "aws route53 create-vpc-association-authorization ${local.cli_flags}"
  destroy_cmd     = "aws route53 delete-vpc-association-authorization ${local.cli_flags}"
}

module "associate_vpc_with_zone" {
  source = "../../cli_resource"

  # Uses the default provider account id if no account id is passed in
  role            = "TF_Role"
  cmd             = "aws route53 associate-vpc-with-hosted-zone ${local.cli_flags}"
  destroy_cmd     = "aws route53 disassociate-vpc-from-hosted-zone ${local.cli_flags}"

  # Require that the above resource is created first 
  dependency_ids  = ["${module.create_vpc_association_authorization.id}"] 
}
```
