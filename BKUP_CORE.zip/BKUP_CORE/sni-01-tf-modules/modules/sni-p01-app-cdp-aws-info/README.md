# sni-p01-util-aws-info

this is a small module to overcome a limitation with terraform.
if you have a cross-account access and want to gather info on the delegated account from the root module (where the configuration using modules lives) the data provider doesnt let you use a alias provider.

## how to use

```hcl
module "awsinfo" {
  providers = {
    aws = aws.aws-assume
  }
  source        = "./modules/sni-p01-util-aws-info"
}

output "region" {
    value = module.awsinfo.region
}
output "account_id" {
    value = module.awsinfo.account_id
}
```
