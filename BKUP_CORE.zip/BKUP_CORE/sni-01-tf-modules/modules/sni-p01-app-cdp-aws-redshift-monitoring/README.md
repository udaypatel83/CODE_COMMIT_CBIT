# Module `sni-p01-app-cdp-aws-redshift-monitoring`

This module sets up advanced monitoring following the guidelines
of awslabs 'redshift monitoring' available at [this link](https://github.com/awslabs/amazon-redshift-monitoring).

![Dashboard](dashboard.png)

A json file is provided inside the lambda zip where additional queries can be added, if necessary.

### Provider Requirements:

- **aws:** (2.20+)

## Redshift database preparation

This module requires the database to be ready for querying.
Therefore, a user is needed for this specific purpose.
To create it, connect to the cluster and issue the following commands:

```
create user "redshift_monitoring" with password 'password';
create group "monitoring" with user redshift_monitoring;
grant select on all tables in schema pg_catalog to redshift_monitoring;
```

The above step needs to be done only once.

## Input Variables

- `aggregation_interval` (default `"1 hour"`): Interval for aggregating statistics
- `cluster_fqdn` (required): Redshift cluster hostname
- `cluster_name` (required): Redshift Cluster Name
- `cluster_port` (default `5439`): Cluster port
- `database_name` (default `"redshift_monitoring"`): Database name
- `database_password_encrypted` (required): Database password, encrypted and presented as string
- `database_user` (default `"redshift_monitoring"`): Database user
- `kms_key_name` (default `"redshift-monitoring"`): Name of the KMS key used for decryption
- `lambda_filename` (required): path to file for the lambda
- `lambda_function_name` (required): Lambda function name
- `lambda_handler` (default `"lambda_function.lambda_handler"`): Lambda handler
- `security_group_ids` (required): Security groups for Redshift access
- `subnet_ids` (required): Subnet IDs
- `tags` (required): tags

## Output Values

- `kms_key_arn`
- `lambda_arn`

## Managed Resources

- `aws_cloudwatch_event_rule.cloudwatch_event_rule` from `aws`
- `aws_cloudwatch_event_target.check_foo_every_five_minutes` from `aws`
- `aws_iam_policy.iam_policy_cloudwatch_metrics` from `aws`
- `aws_iam_policy.iam_policy_iam_policy_document_kms_decrypt` from `aws`
- `aws_iam_role.lambda_iam_role` from `aws`
- `aws_iam_role_policy_attachment.iam_policy_attachment_aws` from `aws`
- `aws_iam_role_policy_attachment.iam_policy_attachment_cloudwatch_metrics` from `aws`
- `aws_iam_role_policy_attachment.iam_policy_attachment_iam_policy_document_kms_decrypt` from `aws`
- `aws_kms_alias.alias` from `aws`
- `aws_kms_key.kms_key` from `aws`
- `aws_lambda_function.lambda` from `aws`
- `aws_lambda_permission.lambda_permission` from `aws`

## Data Resources

- `data.aws_caller_identity.current` from `aws`
- `data.aws_iam_policy_document.assumerole_policy` from `aws`
- `data.aws_iam_policy_document.iam_policy_document_cloudwatch_metrics` from `aws`
- `data.aws_iam_policy_document.iam_policy_document_kms_decrypt` from `aws`
- `data.aws_region.current` from `aws`

## Building the lambda function

The function needs some requirements bundled inside the deployment package.
please follow the instructions to build the package at awslabs 'redshift monitoring' [this link](https://github.com/awslabs/amazon-redshift-monitoring).
then put the zip bundle inside the `SAM` subdir of this module, referencing it in the configuration.
