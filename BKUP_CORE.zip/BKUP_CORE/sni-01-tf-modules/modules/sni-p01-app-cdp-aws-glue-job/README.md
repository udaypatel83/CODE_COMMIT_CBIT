# Module `sni-p01-app-cdp-aws-glue-job`

Provider Requirements:

- **aws:** (any version)

## Input Variables

- `bucket_scripts_name` (required): bucket where scripts reside. must exist. required.
- `bucket_temporary_name` (required): bucket where scripts will deposit temporary data after a run. must exist. required.
- `gluejob_default_concurrent_runs` (default `1`): max_concurrent_runs. defaults to aws' 1
- `gluejob_default_dpu` (default `5`): allocated_capacity for the job (in DPU). numeric
- `gluejob_default_enable_metrics` (default `true`): Whether to enable spark metrics for the glue job. Boolean.
- `gluejob_default_job_bookmark_flag` (required): Enable Job Bookmarks
- `gluejob_default_language` (default `"python"`): language to use with jobs
- `gluejob_default_role_arn` (required): glue IAM role to attach to the job. required.
- `gluejob_default_security_configuration` (default `"main"`): security configuration for encryption
- `gluejob_default_timeout_in_minutes` (default `2880`): glue job timeout, in minutes.
- `jobs` (required): A map of objects about jobs and their properties

The jobs map is composed as follows:

```hcl
variable "jobs" {
    jobname = {
    arguments       = object({})
    dependencies    = list(string)
    tags            = map(string)
    language        = string
    security        = string
    dpu             = number
    timeout         = number
    metrics         = bool
    job_bookmark    = bool
    }
}
```

Each object with key and set of attributes.
A working example:

```hcl
  default = {
    finance_load = {
      "script_filename" = "finance_load.py"
      "glue_job_name"   = "finance_load-test"
      "arguments" = {
        "s3_file"          = "dummy.csv"
        "target_database"  = "sni"
        "staging_table"    = "tm1.stg_fact_finance"
        "debug_mode"       = "True"
        "fact_table"       = "tm1.fact_finance_test"
        "redshift_tmp_dir" = "s3://aws-glue-temporary-783569832862-us-east-2/"
        "raw_table"        = "tm1.raw_sgtp_hfm_planning"
      }
      "dependencies" = []
      "tags"         = {}
    }
  }
}
```

## Output Values

- `arns`
- `ids`: Glue Job IDs

## Managed Resources

- `aws_glue_job.glue_job` from `aws`

## Data Resources

- `data.aws_caller_identity.current` from `aws`
- `data.aws_region.current` from `aws`
