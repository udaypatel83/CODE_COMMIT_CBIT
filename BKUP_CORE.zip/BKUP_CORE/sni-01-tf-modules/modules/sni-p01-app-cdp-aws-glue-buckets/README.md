# Module `sni-p01-app-cdp-aws-glue-buckets`

Module to create bucket specific to glue.

This module will provision buckets and prefix following the aws naming convention:
`aws-glue-accountid-type`

Provider Requirements:

- **aws:** (any version)

## Input Variables

- `account_id` (required): account ID to use. Defaults to current.
- `bucket_lifecycle_expiration` (required): Set a expiration limit (in days). optional
- `bucket_suffix` (required): Suffix to add at the end of the bucket. optional.
- `bucket_versioning` (default `true`): enable versioning on the bucket
- `environment` (required): Logical Environment
- `force_destroy` (default `false`): automatically remove a bucket on terraform destroy
- `region` (required): Region to run in. Defaults to current.
- `tags` (required): Tags. optional.

## Output Values

- `glue_scripts_bucket_arn`
- `glue_scripts_bucket_id`
- `glue_temp_bucket_arn`
- `glue_temp_bucket_id`

## Managed Resources

- `aws_s3_bucket.glue_scripts` from `aws`
- `aws_s3_bucket.glue_temp` from `aws`
- `aws_s3_bucket_object.glue_scripts_prefix` from `aws`
- `aws_s3_bucket_object.glue_spooltemp_prefix` from `aws`

## notes

Buckets are created with `force_destroy` set to false by default.
