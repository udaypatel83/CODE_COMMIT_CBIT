# Module `sni-p01-app-cdp-aws-buckets`

Generic module to create bucket and enforce retention policies.

Provider Requirements:

- **aws:** (any version)

## Input Variables

- `bucket_map` (required): map of buckets and properties
- `bucket_object_prefix_map` (required): map of prefix to prefill a bucket with
- `environment` (required): Logical environment. optional
- `region` (required): aws region for the bucket. defaults to current
- `tags` (required)

Bucket map is composed as follows:

```hcl
  bucket_map = {
    /*
      type = map(object({
        prefix = string
        acl = string
        destroyable = bool
        versioning = bool
        expiration_days = string
        transition_days = string
        storage_class = string
      }))
  }
```

## Output Values

- `_bucket_map`
- `_bucket_object_prefix_map`
- `_bucket_object_prefix_map_obj`
- `arn_map`: A map of bucket names to their arns
- `bucket_arn`: Bucket ARN
- `bucket_id`: Bucket ID (name)

## Managed Resources

- `aws_s3_bucket.s3_bucket` from `aws`
- `aws_s3_bucket_object.s3_bucket_object` from `aws`

## Data Resources

- `data.aws_caller_identity.current` from `aws`
- `data.aws_region.current` from `aws`

## notes

Buckets are created with `force_destroy` set to false by default.
