# Module `sni-p01-app-cdp-aws-sns-topic`

This module provisions a sns topic.

Provider Requirements:

- **aws:** (any version)

## Input Variables

- `encrypt_kms_key` (required): KMS key alias to encrypt the contents with. optional.
- `tags` (required): Tags. optional.
- `topic_name` (required): SNS topic name

## Output Values

- `topic_arn`
- `topic_id`
- `topic_name`

## Managed Resources

- `aws_sns_topic.sns_topic` from `aws`

### notes

The policy management related to the topic is managed by the `sni-p01-app-cdp-aws-sns-topic-policy` instead.
The reason is that policy creation needs to happen before the topic creation when a bucket notification is created, as the bucket references the topic. [https://aws.amazon.com/premiumsupport/knowledge-center/unable-validate-destination-s3/])[Details here.]
