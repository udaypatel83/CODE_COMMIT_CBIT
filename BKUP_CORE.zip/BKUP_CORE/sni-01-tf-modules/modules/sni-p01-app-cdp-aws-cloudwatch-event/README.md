# Module `sni-p01-app-cdp-aws-cloudwatch-event`

Provider Requirements:

- **aws:** (2.20)

## Input Variables

- `cloudwatch_events` (required): list of event maps to describe events

```hcl
variable "cloudwatch_events" {
  type = list(object({
      name = string // name of the event
      description = string
      sns_topic = string // sns topic name where to send notifications to
      source = string // list of source services, separated by comma
      detail-type = string // list of actual events to trigger a notification for
    })
  )
}
```

`detail-type` is a comma-separated list of events to capture.

## Output Values

- `arn`

## Managed Resources

- `aws_cloudwatch_event_rule.cloudwatch_event_rule` from `aws`
- `aws_cloudwatch_event_target.cloudwatch_event_target` from `aws`

## Data Resources

- `data.aws_sns_topic.sns_topic` from `aws`
