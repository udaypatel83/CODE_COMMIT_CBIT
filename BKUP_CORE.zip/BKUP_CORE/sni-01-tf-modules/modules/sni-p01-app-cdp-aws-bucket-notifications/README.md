# Module `sni-p01-app-cdp-aws-bucket-notifications`

To create aws bucket notifications with specific object (file) filters.

Provider Requirements:

- **aws:** (any version)

## Input Variables

- `bucket_object_notification_map` (required): Object map (each object with prefix and suffix keys) to trigger notifications for. optional.

The map object is created as follows:

```hcl
bucket_object_notification_map = {
/*
    type = map(object({
    bucket_name = string
    topic_arn = string
    events = list(string)
    prefix = string
    suffix = string
    }))
*/
    "${module.glue_p360_jobs.p360_staging_bucket_id}" = {
        events    = ["s3:ObjectCreated:*", ]
        prefix    = "/product_hierarchy"
        suffix    = ".csv"
        topic_arn = module.sns_topic_glue_s3_events.topic_arn
    }
}
```

## Output Values

- `_bucket_object_notification_map`
- `_bucket_object_notification_map_obj`

The above are internal outputs; for debugging only.

## Managed Resources

- `aws_s3_bucket_notification.s3_bucket_notification` from `aws`

## notes

This module needs to be executed in a specific order to be compliant with AWS rules.
The order is: `bucket > sns topic > sns topic policy > bucket notification`
